<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<link rel="stylesheet" href="css/bootstrap.css" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<body>

<style>
body{
	background-color:#F0F0FF;
	}

</style>
<br /><br /><br />
<form class="form-horizontal" action="loginstu2.php" method="post">
<div class="row">
<div class="col-lg-1"></div>
<div class="col-lg-1">
<label for="urollno">Username</label></div> <div class="col-sm-3"> <input type="number" class="form-control" id="urollno" placeholder="Enter university roll no" name="urollno"> </div></div><br /><br />

<div class="row">
<div class="col-lg-1"></div>
<div class="col-lg-1">
<label for="email">Password</label></div> <div class="col-sm-3"> <input type="password" class="form-control" id="email" placeholder="Enter email id" name="email"> </div><br /><br /></div>
<div class="row">
<div class="col-lg-3"></div>
<div class="col-lg-4"><br /><br />
<input type="submit" /></div></div>
</form>

<script src="js/bootstrap.js"></script>
<script src="js/jquery-1.11.0.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>

